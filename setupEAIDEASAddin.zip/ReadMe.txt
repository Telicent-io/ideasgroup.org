Thankyou for downloading the Model Futures IDEAS Add-In for Sparx Enterprise Architect(TM)

This software is a Beta release, which means it may have bugs. As with any Beta release, the bugs may corrupt data in Sparx. We recommend that you back up all your work prior to trying the Add-In.

Model Futures Ltd. accepts no responsbility for the consequences of bugs in Beta software. You will be using this software AT YOUR OWN RISK.

If you're happy to go ahead and install and use the Add-In at your own risk then please click on "I Agree" below.

All executable code is (c) Model Futures 2006-2010. The IDEAS UML Profile was partially funded by the UK MOD.


INSTRUCTIONS FOR USE:

* First of all, run the setup to install the AddIn.
* Start Sparx EA
* Create a new Sparx EAP file, or open and existing one (remember, this is beta software, so backup any files before opening them)
* The simplest way to get started is simply to add an IDEAS Diagram (add a diagram and select IDEAS Diagram from the wizard)
* Alternatively, you can add a model using the Sparx Model wizard (select IDEAS Model). This will also create a local copy of the IDEAS Foundation ontology should you wish to refer to or re-use any foundation elements.

Bug reports, queries and feature requests should be sent to ian@modelfutures.com
